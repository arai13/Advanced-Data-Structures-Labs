Ashutosh Rai
README for lab1 for CS 335

Sources Used:
1) Data Structures and Algorithms in Python ?- Michael T. Goodrich, Roberto Tamassia, Michael H. Goldwasser
