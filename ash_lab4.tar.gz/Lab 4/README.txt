Ashutosh Rai
README for lab4 for CS 335

Instructions:
* To run the programs, you can use "python (filename)" in the command line. The filenames should be self-descriptive.
* To run the tests, you could also type "python -m unittest -v" in the command line.

Sources Used:
1) Data Structures and Algorithms in Python - Michael T. Goodrich, Roberto Tamassia, Michael H. Goldwasser
2) http://stackoverflow.com/questions/16257761/difference-between-red-black-trees-and-avl-trees
3) http://stackoverflow.com/questions/13852870/red-black-tree-over-avl-tree
4) https://www.quora.com/Whats-the-difference-between-AVL-trees-and-Red-Black-trees
5) https://attractivechaos.wordpress.com/2008/10/02/comparison-of-binary-search-trees/
