Tugii and Ash
README for lab 5 (CS 335)

Instructions:
* To run the program, you can type "python tugii_ash_lab5.py" in the command line. The file contains the implementation of the binomial heap as well as the tests.

