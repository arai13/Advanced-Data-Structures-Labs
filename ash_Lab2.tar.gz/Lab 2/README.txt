Ashutosh Rai
README for lab2 for CS 335

Instructions:
* To run the programs, you can use "python (filename)" in the command line. The filenames should be self-descriptive.
* To run the tests, you could also type "python -m unittest -v" in the command line.

Sources Used:
1) Data Structures and Algorithms in Python ?- Michael T. Goodrich, Roberto Tamassia, Michael H. Goldwasser
