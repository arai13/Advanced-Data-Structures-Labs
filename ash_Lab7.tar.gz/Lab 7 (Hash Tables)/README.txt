Ashutosh Rai
README for lab7 for CS 335

Instructions:
* To run the programs, you can use "python (filename)" in the command line. The filenames should be self-descriptive (named according to the part in the prompt).

Sources Used:
1) Data Structures and Algorithms in Python - Michael T. Goodrich, Roberto Tamassia, Michael H. Goldwasser
2) https://docs.python.org/3/tutorial/datastructures.html#dictionaries
3) https://docs.python.org/3/library/stdtypes.html#typesmapping
4) http://stackoverflow.com/questions/327311/how-are-pythons-built-in-dictionaries-implemented

